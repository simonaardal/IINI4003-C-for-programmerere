#include <gtkmm.h>
#include <iostream>

class Window : public Gtk::Window {
public:
  Gtk::VBox vbox;
  Gtk::Entry entry;
  Gtk::Entry entry2;
  Gtk::Button button;
  Gtk::Label label;
  bool n1 = false;
  bool n2 = false;

  Window() {

    

    this->set_title("Øving 4");
    button.set_label("Click here");
    button.set_sensitive(false);
    vbox.pack_start(entry);  //Add the widget entry to vbox
    
    vbox.pack_start(button); //Add the widget button to vbox
    vbox.pack_start(entry2); 
    vbox.pack_start(label);  //Add the widget label to vbox

    add(vbox);  //Add vbox to window  
    show_all(); //Show all widgets

    entry.signal_changed().connect([this]() {
       std::cout << entry.get_text() << std::endl;
      if(entry.get_text() == ""){
        n1 = false;
        this->button.set_sensitive(false);
      }else{
        this->n1 = true;
      }
      if(n1 == true && n2 == true){
        this->button.set_sensitive(true);
      }
    });

    entry2.signal_changed().connect([this]() {
      std::cout << entry2.get_text() << std::endl;
      if(entry2.get_text() == ""){
        n2 = false;
        this->button.set_sensitive(false);
      }else{
        this->n2 = true;
      }
      if(n1 == true && n2 == true){
        this->button.set_sensitive(true);
      }
    });

    button.signal_clicked().connect([this]() {
      label.set_text("Names combined: " + entry.get_text() + " " + entry2.get_text());
    });
  }
};

int main() {
  Gtk::Main gtk_main;
  Window window;
  gtk_main.run(window);
}
